# this is the first big project i did, its pretty messy but it should work #
#things to fix: make save and loading into a .txt file (its in the syllabus you should know this if you dont go look at the slides in google classroom)#
#cat lady is at pos 109#
#herb guy is at pos 133#
#old lady is at pos 135#
import random
import math

interaction = ""
description = ""
fixedword = ""
mapspot = 85
interactable = 0
fixedhelp = ""
totalmoney = 22
inventory = ""

# Player stats
statpoints = 55
HP = 0
maxHP = 0
STR = 0
DEX = 0
CON = 0
INT = 0
WIS = 0
CHA = 0
AC = 0
randomlimiter = 0
total_necrotic_damage = 0
total_damage = 0
enemy_damage = 0
print("welcome to Character Creation, User")

while True:
    HP = 28 + ((CON - 10) // 2)
    maxHP = HP
    AC = 10 + ((DEX - 10) // 2)
    creation = input(
        "\nWhat would you like to do? 1: change stats, 2: view stats, 3: randomise stats, 4: exit character creation: "
    ).lower()

    if creation == "4":
        # Exit character creation
        break

    elif creation == "3":
        # Randomize stats
        statpoints = 55
        STR = DEX = CON = INT = WIS = CHA = 0

        stats = ["STR", "DEX", "CON", "INT", "WIS", "CHA"]
        while statpoints > 0:
            for stat in stats:
                if statpoints > 0:
                    # Limit the random allocation to ensure points are balanced
                    randomlimiter = min(10, statpoints)
                    points = random.randint(1, randomlimiter)
                    if stat == "STR":
                        STR += points
                    elif stat == "DEX":
                        DEX += points
                    elif stat == "CON":
                        CON += points
                    elif stat == "INT":
                        INT += points
                    elif stat == "WIS":
                        WIS += points
                    elif stat == "CHA":
                        CHA += points
                    statpoints -= points

        # Calculate HP and AC based on randomized stats
        maxHP = 28 + ((CON - 10) // 2)
        HP = maxHP
        AC = 10 + ((DEX - 10) // 2)

        print(f"SP = {statpoints}  - points remaining")
        print(f"HP = {HP}  - current health")
        print(f"HP = {maxHP}  - total health")
        print(f"STR = {STR}  - strength")
        print(f"DEX = {DEX}  - dexterity")
        print(f"CON = {CON}  - constitution")
        print(f"INT = {INT}  - intelligence")
        print(f"WIS = {WIS}  - wisdom")
        print(f"CHA = {CHA}  - charisma")
        print(f"AC = {AC}  - armor class")

    elif creation == "2":
        # View current stats
        print(f"SP = {statpoints}  - points used to change stats")
        print(f"HP = {HP}  - current health")
        print(f"HP = {maxHP}  - total health")
        print(f"STR = {STR}  - strength")
        print(f"DEX = {DEX}  - dexterity")
        print(f"CON = {CON}  - constitution")
        print(f"INT = {INT}  - intelligence")
        print(f"WIS = {WIS}  - wisdom")
        print(f"CHA = {CHA}  - charisma")
        print(f"AC = {AC}  - armor class")

    elif creation == "1":
        while True:
            change = input(
                f"\nWhat would you like to change? \nSTR, DEX, CON, INT, WIS or CHA? E to exit\ncurrent SP: {statpoints}\n(strength, dexterity, constitution, intelligence, wisdom, charisma)\n"
            )
            if change == "STR" or change == "str":
                STRchange = input("\nWhat should the new strength stat be?: ")
                if STRchange.isdigit() or int(STRchange) > statpoints:
                    statpoints += STR
                    STR = int(STRchange)
                    statpoints -= int(STRchange)
                else:
                    print("invalid number")

            elif change == "DEX" or change == "dex":
                DEXchange = input("\nWhat should the new dexterity stat be?: ")
                if DEXchange.isdigit() or int(DEXchange) > statpoints:
                    statpoints += DEX
                    DEX = int(DEXchange)
                    statpoints -= int(DEXchange)
                else:
                    print("invalid number")

            elif change == "CON" or change == "con":
                CONchange = input(
                    "\nWhat should the new constitution stat be?: ")
                if CONchange.isdigit() or int(CONchange) > statpoints:
                    statpoints += CON
                    CON = int(CONchange)
                    statpoints -= int(CONchange)
                else:
                    print("invalid number")

            elif change == "INT":
                INTchange = input(
                    "\nWhat should the new intellegience stat be?: ")
                if INTchange.isdigit() or int(INTchange) > statpoints:
                    statpoints += INT
                    INT = int(INTchange)
                    statpoints -= int(INTchange)
                else:
                    print("invalid number")

            elif change == "WIS" or change == "wis":
                WISchange = input("\nWhat should the new wisdom stat be?: ")
                if WISchange.isdigit() or int(WISchange) > statpoints:
                    statpoints += WIS
                    WIS = int(WISchange)
                    statpoints -= int(WISchange)
                else:
                    print("invalid number")

            elif change == "CHA" or change == "cha":
                CHAchange = input("\nWhat should the new charisma stat be?: ")
                if CHAchange.isdigit() or int(CHAchange) > statpoints:
                    statpoints += CHA
                    CHA = int(CHAchange)
                    statpoints -= int(CHAchange)
                else:
                    print("invalid number")

            elif change == "E":
                break

            else:
                print("invalid choice")
# Quest system using lists
quest_names = ["Find the Lost Cat", "Gather Herbs", "Defeat The Thugs"]
quest_descriptions = [
    "A villager has lost their cat. Find and return it.",
    "Collect 3 herbs from the trees.",
    "Confront the Thugs and take back the old lady's purse."
]
quest_statuses = ["not started", "not started", "not started"]
found_herbs = 0  # Track herbs collected
thugs_defeated = 0  # 0 if undefeated, 1 if defeated

# Descriptions of places
wilderness_desc = "The Wilderness. Everything gives you an eerie feeling, and you don't want to go any further."
house_desc = "This is someone's house. It's decorated nicely, at least one person is still living here."
trees_desc = "A tree, it's actually pretty sturdy, vibrant green leaves attached to it."
street_desc = "The street, paved with basalt, and it emits warmth, just enough to feel comfortable."
stall_desc = "A stall, someone here is selling things, it gives off a smell you'd have nostalgia about."
townhall_desc = "The Town Hall, where many people are walking about, some chatting happily, and others just hanging out."

def coloured_square(hex_string):
    # returns a colored square with the given hex color #
    hex_string = hex_string.strip("#")
    assert len(hex_string) == 6
    red = int(hex_string[:2], 16)
    green = int(hex_string[2:4], 16)
    blue = int(hex_string[4:6], 16)

    return f"\033[48:2::{red}:{green}:{blue}m  \033[49m"

wilderness = coloured_square("001e00")
houses = coloured_square("664229")
trees = coloured_square("008000")
street = coloured_square("333333")
stalls = coloured_square("FFEE8C")
townhall = coloured_square("45b6fe")
player = coloured_square("FF0000")

def display_map():
    map_grid = [
        ['W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W'],
        ['W', 'H', 'H', 'H', 'T', 'H', 'S', 'H', 'T', 'H', 'H', 'H', 'W'],
        ['W', 'S', 'S', 'S', 'H', 'S', 'S', 'S', 'H', 'S', 'S', 'S', 'W'],
        ['W', 'H', 'H', 'S', 'C', 'C', 'S', 'C', 'C', 'S', 'H', 'H', 'W'],
        ['W', 'H', 'T', 'S', 'H', 'S', 'S', 'S', 'H', 'S', 'T', 'H', 'W'],
        ['W', 'S', 'H', 'S', 'C', 'C', 'S', 'C', 'C', 'S', 'H', 'S', 'W'],
        ['W', 'S', 'S', 'S', 'S', 'S', 'B', 'S', 'S', 'S', 'S', 'S', 'W'],
        ['W', 'S', 'H', 'S', 'C', 'C', 'S', 'C', 'C', 'S', 'H', 'S', 'W'],
        ['W', 'H', 'T', 'S', 'H', 'S', 'S', 'S', 'H', 'S', 'T', 'H', 'W'],
        ['W', 'H', 'H', 'S', 'C', 'C', 'S', 'C', 'C', 'S', 'H', 'H', 'W'],
        ['W', 'S', 'S', 'S', 'H', 'S', 'S', 'S', 'H', 'S', 'S', 'S', 'W'],
        ['W', 'H', 'H', 'H', 'T', 'H', 'S', 'H', 'T', 'H', 'H', 'H', 'W'],
        ['W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W', 'W'],
    ]

    # Color code dictionary
    color_dict = {
        'W': "001e00",
        'H': "664229",
        'T': "008000",
        'S': "333333",
        'C': "FFEE8C",
        'B': "45b6fe"
    }

    # Build a map with colored squares
    map_paste = []
    for row in map_grid:
        colored_row = []
        for cell in row:
            colored_row.append(coloured_square(color_dict.get(cell, "000000")))  # default black if unknown
        map_paste.append(colored_row)

    # Mark the player position
    row_index, col_index = divmod(mapspot, 13)
    col_index = max(0, col_index - 1)
    map_paste[row_index][col_index] = coloured_square("FF0000")  # red for player

    # Print the map
    for row in map_paste:
        print("".join(row))


def display_quests():
    print("\nCurrent Quests:")
    for i in range(len(quest_names)):
        print(
            f"{i+1}. {quest_names[i]} - {quest_descriptions[i]} (Status: {quest_statuses[i]})"
        )


def update_quest_status(quest_index, status):
    quest_statuses[quest_index] = status


def check_quest_completion():
    global totalmoney, found_herbs, DEX, WIS
    # Check for completion of "Find the Lost Cat"
    if quest_statuses[
            0] == "in progress" and mapspot == 107 and DEX >= 16:  # player finds cat in the tree
        totalmoney += 5
        print(
            "\nYou have found the lost cat and returned it to the villager! (+5 dollars)"
        )
        update_quest_status(0, "completed")
    elif quest_statuses[0] == "in progress" and mapspot == 107 and DEX < 16:
        print(
            "\nYou try to catch the cat, but are unable to get it down the tree, as the cat is still scared and dosent wish to come down to your arms, maybe you can find a cat toy around somewhere? Surely one of the Stalls has one."
        )

    # Check for completion of "Gather Herbs"
    if quest_statuses[1] == "in progress" and found_herbs >= 3:
        totalmoney += 10
        print("\nYou have gathered 3 herbs! (+10 dollars)")
        update_quest_status(1, "completed")

    # Check for completion of "Defeat The Thugs"
    if quest_statuses[2] == "in progress" and thugs_defeated == 1:
        totalmoney += 15
        print("\nYou have deafeated the thugs! (+15 dollars)")
        update_quest_status(1, "completed")


def interact_desc():
    global mapspot, interaction, description, inventory, totalmoney
    stall_spots = {
        45, 47, 48, 70, 71, 73, 44, 74, 96, 97, 99, 100, 122, 123, 125, 126
    }
    if mapspot in stall_spots:
        while True:
            interaction = "You're talking to a stall vendor, he says:"
            description = "\nWelcome to the stall! Here are the items you can buy:\n1. Book - $10\n2. Cat Toy - $5\n3. Glasses - $7\n4.Exit - $0\nWhat would you like to buy? (Enter 1, 2, or 3)"
            print(f"{interaction}\n{description}")
            choice = input()
            if choice == '1' and totalmoney >= 10:
                inventory += "\nBook"
                totalmoney -= 10
                description = "You bought a Book! +5 INT"
                global INT
                INT += 5
                item = 1
            elif choice == '2' and totalmoney >= 5:
                inventory += "\nCat Toy"
                totalmoney -= 5
                description = "You bought a Cat Toy! + 5 CHA"
                global CHA
                CHA += 5
                item = 1
            elif choice == '3' and totalmoney >= 7:
                inventory += "\nGlasses"
                totalmoney -= 7
                description = "You bought Glasses! + 5 WIS"
                global WIS
                WIS += 5
            elif choice == '4':
                if inventory == "":
                    print(
                        "\nYou wave Goodbye to the stall owner and walk off, empty handed."
                    )
                else:
                    print(
                        "\nYou wave Goodbye to the stall owner, your other hand preoccupied with holding your stuff"
                    )
                break

            #2382938298392839283928938238928392839283829839283928398293829382983928
            else:
                description = "You don't have enough money for that item or invalid choice."
            print(description)
    elif mapspot == 85:
        interaction = "You see the Town Hall board."
        description = "Welcome to the world! You are a friendly Neighbourhood Scout.\nToday is Job week, which means this week, you go around, asking people if they need anything done, and in return you get $5!\nYou can turn in whenever you want, and you can see how well you did! Good luck!"

    elif mapspot == 109:
        interaction = "a villager."
        print(interaction)
        if quest_statuses[0] == "not started":
            questask = input("The villager looks worried, saying: 'I've lost my cat! Can you help me find it?'\n\n(Accept quest? Y/N)\n")
            if questask.lower() == 'y':
                update_quest_status(0, "in progress")
                print("\nQuest Accepted: Find the Lost Cat")
        elif quest_statuses[0] == "in progress":
            description = "The villager paces back and fourth, saying: 'Have you found him yet? No? Oh dear...I'm worried sick!' \n"
            print(f"{interaction}\n{description}")
        elif quest_statuses[0] == "completed":
            description = "The villager smiles at you, saying: 'Thank you so much for finding my cat!\n"
            print(f"{interaction}\n{description}")
        

    elif mapspot == 113:
        interaction = "a townsperson."
        print(interaction)
        if quest_statuses[1] == "not started":
            questask = input("He looks like hes in deep thought, mumbling: 'I'll have to find some herbs...where were they again? some...trees had them?' \n\n(Accept quest? Y/N)\n")
            if questask.lower() == 'y':
                update_quest_status(1, "in progress")
                print("\nQuest Accepted: Gather Herbs")
        elif quest_statuses[1] == "in progress":
            description = "He turns to you, tilting his head, saying: 'You dont seem to have the herbs yet, maybe you should go find them? They grow on trees.'\n"
            print(f"{interaction}\n{description}")
        elif quest_statuses[1] == "completed":
            description = "He turns to you, smiling and patting your shoulder, saying: 'Thank you for the herbs, you are a great help!'\n"
            print(f"{interaction}\n{description}")
        

    elif mapspot == 135:
        interaction = "an old lady."
        print(interaction)
        if quest_statuses[2] == "not started":
            questask = input("She looks quite distressed, and is pacing back and fourth, walking up to you and asking: 'P-please, young one, a group of thugs WEST from here had taken my purse, please have them return it to me!' \n\n(Accept quest? Y/N)\n")
            if questask.lower() == 'y':
                update_quest_status(2, "in progress")
                print("\nQuest Accepted: Defeat The Thugs")
        elif quest_statuses[2] == "in progress":
            description = "She's sat on a bench, twiddling her thumbs in anxiety, saying: 'Please, find those thugs and bring them to justice!'\n"
            print(f"{interaction}\n{description}")
        elif quest_statuses[2] == "completed":
            description = "Thank you so much for returning my purse, young one! I am forever in your debt!\n"
            print(f"{interaction}\n{description}")


#wheeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee
    elif mapspot == 132:
        global HP, STR, DEX, CON
        interaction = "You come across a group of Thugs"
        description = "One of them is holding a purse that sticks out like a sore thumb, it's the old lady's purse! Confront them? (Y/N)"
        print(f"{interaction}\n{description}")
        if input().lower() == 'y':
            print("Encounter, START!")

            # Initialize combat variables
            thugs = {"Thug 1": 20, "Thug 2": 20, "Thug 3": 20}
            rounds = 1
            player_dodged = False
            player_defending = False

            while any(hp >= 0 for hp in thugs.values()) and HP > 0:
                print(
                    f"\nRound {rounds}!\nTurn order: Thug 1, Thug 2, You, Thug 3\nHP: {HP}"
                )
                print(f"\nEnemies:")
                for thug, hp in thugs.items():
                    print(f"{thug}, HP {hp}")

                action = input(
                    "\nActions: Attack, Dodge, Defend, Focus, Call\nWhat will you do?: "
                ).lower()
                player_dodged = False
                player_defending = False

                if action == "attack":
                    attackwho = input("Which thug to attack? (1, 2, or 3): ")
                    if attackwho in ["1", "2", "3"]:
                        target = f"Thug {attackwho}"
                        if thugs[target] >= 0:
                                damage = math.ceil(1+ STR/2)
                                thugs[target] -= damage
                                if thugs[target] < 0:
                                    thugs[target] = 0
                                print(
                                    f"\nYou attacked {target} for {damage} damage!"
                                )
                        else:
                            print(f"{target} is already down!")

                elif action == "dodge":
                    print("You prepare to dodge the next attack!")
                    player_dodged = True

                elif action == "defend":
                    parry = random.randint(0, 2)
                    if parry == 1:
                        print("You successfully parried the attack!")
                        # Reflect damage back to one random thug
                        reflect_damage = (random.randint(1, 3) * STR)
                        attacker = random.choice(
                            [key for key, hp in thugs.items() if hp > 0])
                        thugs[attacker] -= reflect_damage
                        print(
                            f"You reflected {reflect_damage} damage back to {attacker}!"
                        )
                    else:
                        print("You brace yourself to reduce incoming damage!")
                        player_defending = True

                elif action == "focus":
                    heal = random.randint(1, 10)
                    HP += heal
                    print(f"You focused and healed {heal} HP!")

                elif action == "call":
                    sent = random.randint(1, 13)
                    if sent in [1, 2, 3, 4]:
                        senddudes = "and as if on cue, you feel a strange force empower you. +2 STR"
                        STR += 2
                    elif sent in [5, 6, 7, 8]:
                        senddudes = "and you hear someone up above put a hand on your shoulder, giving you a boost. +8 HP"
                        HP += 8
                    elif sent in [9, 10, 11, 12]:
                        senddudes = "and you feel empowered by your own thoughts, boosting your confidence. +2 CHA"
                        CHA += 2
                    elif sent == 13:
                        senddudes = "and it seems luck was on your side today, lightning strikes nearby, scaring away one of the thugs."
                        scared_thug = random.choice(
                            [key for key, hp in thugs.items() if hp > 0])
                        thugs[scared_thug] = 0
                    print(f"You call for help, {senddudes}")

                # Thug's turn to attack
                for thug, hp in thugs.items():
                    if hp > 0:
                        thug_tohit = random.randint(1, 20) + 1
                        thug_damage = random.randint(1, 4)
                        if thug_tohit > AC:
                            if player_defending == True:
                                thug_divided = thug_damage / 2
                                HP -= thug_divided
                                print(
                                    f"\n{thug} attacks you for {thug_damage}, but you block and only take {thug_divided} damage!!"
                                )
                            elif player_defending == False:
                                HP -= thug_damage
                                print(
                                    f"\n{thug} attacks you for {thug_damage} damage!!"
                                )
                        else:
                            print(f"\n{thug} tries to attack you, but misses!")
                        thug_tohit = 0
                        thug_damage = 0

                # Check for victory/defeat
                if HP <= 0:
                    print(
                        "You have been defeated by the thugs! You wake up the next morning, In the town hall, laying on a couch."
                    )
                    HP = 30
                    mapspot = 85
                    break
                elif all(hp <= 0 for hp in thugs.values()):
                    print(
                        "You have defeated all the thugs and recovered the purse! \n\n+15 dollars!"
                    )
                    thugs_defeated = 1
                    update_quest_status(
                        2,
                        "completed")  # Update the quest status to "completed"
                    totalmoney += 15
                    check_quest_completion()
                    break

                rounds += 1

#bussyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy
    elif mapspot in [18, 22, 55, 63, 107, 115, 148,
                     152]:  # spot where herbs can be collected

        interaction = "you see some herbs on the tree, but you are unsure if they are poisonous or not. increase your WIS at the library!"
        description = "You find some herbs. Collect them? (Y/N)"
        if WIS >= 16:
            print(description)
            if input().lower() == 'y':
                global found_herbs
                found_herbs += 1
                description = f"\nHerbs Collected: {found_herbs}/3"
                print(description)
                if found_herbs >= 3:
                    description = "\nYou've gathered enough herbs for the quest!"
                    totalmoney += 10
                    quest_statuses
                    print(description)
            elif input().lower() == 'n':
                description = "\nYou decide it isnt worth the trouble to reach up and pick the herbs."
                print(description)
        else:
            print(interaction)
        


# Main game loop and other functions remain unchanged


def introcards():
    global mapspot, fixedword
    intro_card = random.randint(1, 3)
    if intro_card == 1:
        narrationstart = "You find yourself walking into"
    elif intro_card == 2:
        narrationstart = "Now, arriving into"
    elif intro_card == 3:
        narrationstart = "Going into"

    if fixedword in ["west", "w"]:
        mapspot -= 1
    elif fixedword in ["east", "e"]:
        mapspot += 1
    elif fixedword in ["south", "s"]:
        mapspot += 13
    elif fixedword in ["north", "n"]:
        mapspot -= 13

    wilderness_spots = {
        2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 14, 27, 40, 53, 66, 79, 92, 105,
        118, 131, 144, 157, 26, 39, 52, 65, 78, 91, 104, 117, 130, 156, 169,
        158, 159, 160, 161, 162, 163, 164, 165, 166, 167, 168
    }
    if mapspot in wilderness_spots:
        narration = "the wilderness. You feel compelled to not go any further."
        if fixedword == "west" or fixedword == "w":
            mapspot += 1
        elif fixedword == "east" or fixedword == "e":
            mapspot -= 1
        elif fixedword == "south" or fixedword == "s":
            mapspot -= 13
        elif fixedword == "north" or fixedword == "n":
            mapspot += 13
        return f"{narrationstart} {narration}"

    house_spots = {
        15, 16, 17, 19, 21, 23, 24, 25, 31, 35, 41, 42, 50, 51, 54, 57, 61, 64,
        68, 76, 94, 102, 106, 109, 113, 116, 119, 120, 128, 129, 135, 139, 145,
        146, 147, 149, 151, 153, 154, 155
    }
    stall_spots = {
        44, 45, 47, 48, 70, 71, 73, 74, 96, 97, 99, 100, 122, 123, 125, 126
    }
    tree_spots = {18, 22, 55, 63, 107, 115, 148, 152}
    street_spots = {
        19, 20, 22, 26, 27, 28, 29, 30, 32, 33, 34, 36, 37, 38, 40, 43, 45, 46,
        48, 49, 50, 51, 53, 55, 56, 57, 58, 59, 60, 62, 64, 65, 67, 68, 69, 72,
        75, 76, 77, 80, 81, 82, 83, 84, 86, 87, 88, 89, 90, 92, 93, 94, 95, 96,
        98, 100, 101, 102, 103, 104, 106, 108, 110, 111, 112, 114, 115, 118,
        120, 121, 124, 126, 127, 132, 133, 134, 136, 137, 138, 130, 140, 141,
        142, 150
    }

    if mapspot in house_spots:
        narration = house_desc

    elif mapspot in stall_spots:
        narration = stall_desc

    elif mapspot in tree_spots:
        narration = trees_desc

    elif mapspot in street_spots:
        narration = street_desc

    elif mapspot == 85:
        narration = townhall_desc

    else:
        narration = wilderness_desc

    return f"{narrationstart} {narration}"


# Introduction, first thing it prints, then puts you in a loop to play the game
print(
    "You find yourself in a town square, interact with the town hall board to read!\nYou can head north, south, east, or west.\nTo see the map again, type 'map' or 'm'\nType 'help' for help\n"
)

# Main game loop
while True:
    if totalmoney >= 50:
        print(
            "YOU WIN! CONGRATS! Your Job week card has been filled up! You can now go home and rest!"
        )
        break
    word = input("\nWord goes here: ")
    fixedword = word.lower()

    if fixedword == "north" or fixedword == "n":
        print("going north")
        print(introcards())
        interact_desc()  # Updates interaction and description
        check_quest_completion()  # Check if any quests are completed1

    elif fixedword == "south" or fixedword == "s":
        print("going south")
        print(introcards())
        interact_desc()  # Updates interaction and description
        check_quest_completion()  # Check if any quests are completed2

    elif fixedword == "east" or fixedword == "e":
        print("going east")
        print(introcards())
        interact_desc()  # Updates interaction and description
        check_quest_completion()  # Check if any quests are completed3

    elif fixedword == "west" or fixedword == "w":
        print("going west")
        print(introcards())
        interact_desc()  # Updates interaction and description
        check_quest_completion()  # Check if any quests are completed4

    elif fixedword in ["interact", "i"]:
        interact_desc()  # Updates interaction and description
        print(f"{interaction}\n{description}")
        check_quest_completion()  # Check if any quests are completed5

    elif fixedword in ["map", "m"]:
        display_map()  # Shows the map after prompted
        print(f"\nMap information: \n{wilderness} represents wilderness, you are unable to traverse into it.\n{houses} represents houses\n{trees} represents trees\n{street} represents the streets/road\n{stalls} represents stalls\n{townhall} represents the Town Hall\n{player} represents the player\nX represents spots to complete quests")

    elif fixedword == "help":
        print(
            "Type 'north', 'south', 'east', or 'west' to move.\nType 'interact' to interact with the area.\nType 'map' or 'm' to see the map.\nType 'total money' to see your total money.\nType 'inventory' to see your inventory.\nType 'quests' to see your quests.\nType 'info' to see what the map legends mean.\nType 'stats' to see your stats.\nType 'help' to see this again.\nType 'quit' to quit the game."
        )

    elif fixedword == "total money":
        print(f"\n${totalmoney}/ $50 total")

    elif fixedword == "info":
        print(
            f"Map information: \n{wilderness} represents wilderness, you are unable to traverse into it.\n{houses} represents houses\n{trees} represents trees\n{street} represents the streets/road\n{stalls} represents stalls\n{townhall} represents the Town Hall\n{player} represents the player\nX represents spots to complete quests"
        )
    elif fixedword == "stats":
        print(f"HP = {HP}  - health")
        print(f"STR = {STR}  - strength")
        print(f"DEX = {DEX}  - dexterity")
        print(f"CON = {CON}  - constitution")
        print(f"INT = {INT}  - intelligence")
        print(f"WIS = {WIS}  - wisdom")
        print(f"CHA = {CHA}  - charisma")
    elif fixedword == "quests":
        display_quests()  # Display the quests
    elif fixedword == "controls":
        print(
            f"\n(Casing does not matter)\n***List Of Valid Commands:***\n'north' or 'n' results in going north\n'south' or 's' results in going south\n'east' or 'e' results in going east\n'west' or 'w' results in going west\n'interact' or 'i' to interact\n'map' or 'm' to display the map\n'quit' to exit the game"
        )

    elif fixedword == "givememoney":
        print("money given")
        totalmoney += 20

    elif fixedword == "quit":
        print(
            "Exiting the game. I don't know how to save, so good luck! Goodbye!"
        )  # Exits the game
        break
    else:
        print("\nInvalid input, please try again."
              )  # Sends you back to the top to redo the input

    # For testing
    print(f"player position: {mapspot}")
    # print(f"i: {interaction}\nd: {description}")
    # Done testing
